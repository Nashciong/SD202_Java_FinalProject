

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Student.Admin
 */



public class count {
    public static int  countData(String table){
    int total = 0;
        Connection conn = db.Myconnect();
            Statement st;
        try {
            st = conn.createStatement();
            ResultSet rs;
            
        rs = st.executeQuery( "SELECT COUNT(*) AS total FROM "+table+" where Status = \"Disapprove\";");
            
            while(rs.next()){
            
            total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(count.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    
    return total;
    }
    public static int  countdata(String table){
    int total = 0;
        Connection conn = db.Myconnect();
            Statement st;
        try {
            st = conn.createStatement();
            ResultSet rs;
            
        rs = st.executeQuery( "SELECT COUNT(*) AS total FROM "+table+" where Status = \"Approve\";");
            
            while(rs.next()){
            
            total = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(count.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    
    return total;
    }

    
    
}
